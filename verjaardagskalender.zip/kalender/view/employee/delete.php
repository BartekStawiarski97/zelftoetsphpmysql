<?php
// maak een bevestig pagina voor het verwijderen van een mededwerker
?>

