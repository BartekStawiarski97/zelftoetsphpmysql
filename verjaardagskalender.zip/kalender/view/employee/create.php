<h1>Persoon toevoegen</h1>
<form name="create" method="post" action="/kalender/employee/store">
	<!-- bouw hier je formulier -->
	<input type="text" name="name" placeholder="naam">
	<input type="date" name="date" placeholder="datum">	
	<input type="submit" value="Aanmaken!">
</form>